# Sri Sai Electrical Works website

A responsive bilingual (English/Tamil) static website.

## Preview
Open `index.html` in a browser.

## Publish free with GitHub Pages
1. Create a free GitHub account and a new public repository.
2. Upload `index.html` to the repository root.
3. Open Settings → Pages.
4. Under Build and deployment, choose Deploy from a branch, select `main` and `/ (root)`, then Save.
5. GitHub will provide a public website address after deployment.

You can also upload this folder to a static hosting service such as Cloudflare Pages or Netlify.

## Before publishing
- Business phone and WhatsApp are configured as +91 97875 27556. The enquiry form opens WhatsApp with the customer name, phone, full service address and requested service. The customer must press Send in WhatsApp.
- Confirm the exact service area, business hours and any additional services.
- Replace the illustrative graphics with real photos of the business/work if available.
- The enquiry form opens WhatsApp with the enquiry details. It does not store submissions in a database yet.

No subscription or paid website-builder account is needed for the static site itself. A custom domain is optional and may cost extra.
